date_default_timezone_set($timezone_string);
