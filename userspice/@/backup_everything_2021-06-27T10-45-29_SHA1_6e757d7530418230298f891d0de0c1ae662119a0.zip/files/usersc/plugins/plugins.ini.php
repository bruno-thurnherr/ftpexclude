;<?php die();?>
google_login = 1
recaptcha = 1
forms = 1