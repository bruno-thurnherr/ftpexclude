<?php
//Please don't load code on the header of every page if you don't need it on the header of every page.
// bold("<br>Google Login Header.php Loaded");
include $abs_us_root.$us_url_root.'usersc/plugins/google_login/assets/google_oauth.php';
