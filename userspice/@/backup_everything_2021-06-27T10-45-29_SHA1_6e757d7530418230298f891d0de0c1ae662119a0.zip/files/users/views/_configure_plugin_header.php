<div class="col-sm-8">
  <div class="page-header float-right">
    <div class="page-title">
        <ol class="breadcrumb text-right">
          <li><a href="<?=$us_url_root?>users/admin.php">Dashboard</a></li>
          <li class="active">Addons</li>
        </ol>
    </div>
  </div>
</div>
</div>
</header>
