<?php
require_once '../users/init.php';
Redirect::to($us_url_root.'users/updates');
?>
